a = "This is function a!"

b = "This is function b!"

c = "This is function c!"

d = "This is function d!"


caseFunction "a" = a
caseFunction "b" = b
caseFunction "c" = c
caseFunction "d" = d
caseFunction _ = []